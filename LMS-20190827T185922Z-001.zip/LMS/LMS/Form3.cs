﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS
{
    public partial class Student : Form
    {
        public Student(string a)
        {
            InitializeComponent();
            Id.Text = a;
            
        }
        
         
        private void Student_Load(object sender, EventArgs e)
        {
            
            booklist2.Hide();
           
            bookissue1.Hide();

            accinfo1.Hide();
            bookissue1.set(Id.Text);
            accinfo1.set(Id.Text);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {   
            Login a = new Login("", "");
            a.Show();
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            booklist2.Show();
            bookissue1.Hide();
            accinfo1.Hide();
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            
            booklist2.Hide();
            
            bookissue1.Show();
           
            accinfo1.Hide();





        }

        private void button3_Click(object sender, EventArgs e)
        {
            booklist2.Hide();
            bookissue1.Hide();
           
            accinfo1.Show();
            accinfo1.label(Id.Text);
            

        }
    }
}

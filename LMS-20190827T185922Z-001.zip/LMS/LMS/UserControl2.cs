﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LMS
{
    public partial class deletebook : UserControl
    {
        public deletebook()
        {
            InitializeComponent();
        }

        private void deletebook_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";

                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                SqlCommand cmd = new SqlCommand("Delete  from book where book_id ='" + id.Text + "' and stu_id='-'", conn);


                SqlDataReader myreader;
                myreader = cmd.ExecuteReader();

                
        
                id.Clear();
                conn.Close();
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

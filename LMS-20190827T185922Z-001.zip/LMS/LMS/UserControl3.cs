﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LMS
{
    public partial class booklist : UserControl
    {
        
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True");
        public booklist()
        {
            InitializeComponent();
        }

        private void booklist_Load(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from book", conn);
            SqlDataReader myreader;
            myreader = cmd.ExecuteReader();
            while (myreader.Read())
            {
                ListViewItem lv = new ListViewItem(myreader[0].ToString());
                lv.SubItems.Add(myreader[1].ToString());
                lv.SubItems.Add(myreader[2].ToString());
                lv.SubItems.Add(myreader[3].ToString());
                lv.SubItems.Add(myreader[4].ToString());
                listView1.Items.Add(lv);
            }

            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void listView1_ItemActivate(object sender, EventArgs e)
        {
         
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from book", conn);
            SqlDataReader myreader;
            myreader = cmd.ExecuteReader();
            while (myreader.Read())
            {
                ListViewItem lv = new ListViewItem(myreader[0].ToString());
                lv.SubItems.Add(myreader[1].ToString());
                lv.SubItems.Add(myreader[2].ToString());
                lv.SubItems.Add(myreader[3].ToString());
                lv.SubItems.Add(myreader[4].ToString());
                listView1.Items.Add(lv);
            }

            conn.Close();

        }
    }
}

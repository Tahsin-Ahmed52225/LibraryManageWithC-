create table librarian (
  li_id varchar (30) not null,
  li_name varchar(30) not null,
  li_pass varchar(30) not null,
  li_mail varchar(30) not null,
  li_ra varchar(30) not null
)
select *
from librarian

insert into librarian(li_id,li_name,li_pass,li_mail,li_ra)
values ('admin','Tahsin','1234','admin@gmail.com','Riyadh')

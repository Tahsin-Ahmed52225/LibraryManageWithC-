﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace LMS
{
    public partial class Book : Form
    {
        public Book()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            

        }

        private void label6_Click(object sender, EventArgs e)
           
        {
            Close();
            Librarian l = new Librarian();
                l.Show();
        }

        private void Book_Load(object sender, EventArgs e)
        {
            newbook1.Hide();
            deletebook1.Hide();
            booklist1.Hide();
            bookissued1.Hide();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            newbook1.Show();
            deletebook1.Hide();
            booklist1.Hide();
            bookissued1.Hide();
        
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void gpanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void newbook1_Load(object sender, EventArgs e)
        {
            newbook1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            newbook1.Hide();
            deletebook1.Show();
            booklist1.Hide();
            bookissued1.Hide();
            deletebook1.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            newbook1.Hide();
            deletebook1.Hide();
            booklist1.Show();
            bookissued1.Hide();
            booklist1.BringToFront();
         
        }

        private void button4_Click(object sender, EventArgs e)
        {
            newbook1.Hide();
            deletebook1.Hide();
            booklist1.Hide();
            bookissued1.Show();
            bookissued1.BringToFront();
        }

       
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace LMS
{
    public partial class newStu : Form
    {
        public newStu(string ab)
        {
            InitializeComponent();
            id.Text = ab;

        }
       

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";

                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                SqlCommand cmd = new SqlCommand("update  student set stu_pass = '"+pass.Text+"' where  stu_id = '"+id.Text+ "'", conn);
                SqlDataReader myreader;
                myreader = cmd.ExecuteReader();
                MessageBox.Show("Password Changed Sucessfully!");
                conn.Close();
                Login m1 = new Login(id.Text , pass.Text);
                m1.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

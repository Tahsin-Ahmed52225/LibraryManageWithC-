create table book (
  book_id varchar(30) primary key not null,
  book_name varchar(20) not null,
  aurthor varchar(20) not null,
  book_dept varchar(30) not null,
  book_edition varchar(10),
  issu_date varchar(20),
  stu_id varchar(30) ,
  status_ varchar(30)
);
select * from book;
insert into book(book_id,book_name,aurthor, book_dept ,book_edition, issu_date , stu_id)
 values('03', '01', '01', '01', '0', '-' , 'cse06407541')
 update book
  set stu_id = 'CSE0000' , status_ = 'Issued' , issu_date = 'baaal' 
 where book_id ='001'
 select book_id,book_name,book_dept,issu_date from book where stu_id = ''
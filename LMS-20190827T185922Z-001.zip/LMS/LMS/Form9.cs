﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LMS
{
    public partial class listu : Form
    {
        public listu()
        {
            InitializeComponent();
        }

        private void listu_Load(object sender, EventArgs e)
        {
            bookr1.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from student where stu_id ='" + textBox1.Text + "'", conn);
            SqlDataReader myreader;
            myreader = cmd.ExecuteReader();
            if (myreader.HasRows)
            {
                bookr1.Show();
                bookr1.set(textBox1.Text);
                bookr1.label(textBox1.Text);
                bookr1.listv(textBox1.Text);
                
                
            }
            else { MessageBox.Show("This ID is not registered"); }
            conn.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Close();
            Librarian a = new Librarian();
            a.Show();
        }
    }
}

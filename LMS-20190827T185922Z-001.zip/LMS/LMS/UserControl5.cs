﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LMS
{
    public partial class bookissue : UserControl 
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True");
        string option;
        string user1;
     public void set(string a)
        {
           user1 =  a;
        }
        

       

public bookissue()
        {
            InitializeComponent();
           
            
        }

        private void bookissue_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (option == "Name")
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select book_id,book_name,status_ from book where book_name ='"+Search.Text+ "'and status_ ='-' ", conn);
                    SqlDataReader myreader;
                    myreader = cmd.ExecuteReader();
                   
                    while (myreader.Read())
                    {
                        ListViewItem lv = new ListViewItem(myreader[0].ToString());
                        lv.SubItems.Add(myreader[1].ToString());
                        lv.SubItems.Add(myreader[2].ToString());

                        listView1.Items.Add(lv);
                    }

                    conn.Close();
                }
                else if (option == "Department")
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select book_id,book_name,status_ from book where book_dept = '" +Search.Text +"' and status_ ='-'", conn);
                    SqlDataReader myreader;
                    myreader = cmd.ExecuteReader();
                    while (myreader.Read())
                    {
                        ListViewItem lv = new ListViewItem(myreader[0].ToString());
                        lv.SubItems.Add(myreader[1].ToString());
                        lv.SubItems.Add(myreader[2].ToString());

                        listView1.Items.Add(lv);
                    }
                    
                    conn.Close();
                }
                else { MessageBox.Show("Wrong Search word!!");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            option = comboBox1.SelectedItem.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("update book set stu_id = '"+user1+"' , status_ = 'Issued' , issu_date = '" + dateTimePicker1.Text+"' where book_id ='" + ID.Text + "' and status_ ='-'", conn);
            SqlDataReader myreader;
            myreader = cmd.ExecuteReader();
            conn.Close();
            MessageBox.Show("Book is issued  for 7 days");




        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }
    }
}

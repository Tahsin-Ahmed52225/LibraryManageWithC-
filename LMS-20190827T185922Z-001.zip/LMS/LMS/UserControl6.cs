﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LMS
{
    public partial class Accinfo : UserControl
    {
        public void label(string user1)
        {
            try
            {
                string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                SqlCommand cmd = new SqlCommand("select stu_name,stu_gender,stu_dept,stu_num from student where stu_id ='" + user1 + "'", conn);
                SqlDataReader myreader;
                myreader = cmd.ExecuteReader();

                while (myreader.Read())
                {

                    label5.Text = myreader["stu_name"].ToString();
                    label6.Text = myreader["stu_gender"].ToString();
                    label7.Text = myreader["stu_dept"].ToString();
                    label8.Text = myreader["stu_num"].ToString();

                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        string user1;
        public void set(string a)
        {
            user1 = a;
        }

        public Accinfo()
        {
            InitializeComponent();
           


           


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        
{
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Accinfo_Load(object sender, EventArgs e)
            
        {
            string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select book_id,book_name,issu_date from book where stu_id = '"+user1+"'", conn);
            SqlDataReader myreader;
            myreader = cmd.ExecuteReader();
            if (myreader.HasRows)
            {
                while (myreader.Read())
                {
                    string date = myreader["issu_date"].ToString();
                    DateTime oDate = Convert.ToDateTime(date);
                    DateTime Rdate = oDate.AddDays(7);
                    string format = "yyyy MM dd";
                    string RD = Rdate.ToString(format);

                    ListViewItem lv = new ListViewItem(myreader[0].ToString());
                    lv.SubItems.Add(myreader[1].ToString());
                    lv.SubItems.Add(myreader[2].ToString());
                    lv.SubItems.Add(RD);

                    listView1.Items.Add(lv);
                }
            }
            conn.Close();
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }

        
    }


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace LMS
    
{
    
    public partial class SignUp : Form
        
    {
        public SignUp()
        {
            InitializeComponent();
        }
        string gender;
        string dept;

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (name.Text == "" || id.Text == "" || bg.Text == "" || con.Text == "" || mail.Text == "" || add.Text == "" || password.Text == "" || ra.Text == "")
                {
                    MessageBox.Show("Missing infromation !!!");
                }
                else if (password.Text.Length < 4) { MessageBox.Show("Password must have at least 4 character"); }
                else
                {
                    string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";

                    SqlConnection conn = new SqlConnection(cs);
                    conn.Open();
                        SqlCommand cmd = new SqlCommand("insert into student(stu_id,stu_name,stu_gender,stu_dept, stu_dob , stu_num , stu_mail , stu_add ,  stu_ra , stu_pass,stu_state) values('" + id.Text+"', '"+name.Text+"', '"+gender+"', '"+dept+"', '"+dateTimePicker1.Text+"', '"+con.Text+"', '"+mail.Text+"', '"+add.Text+"', '"+ra.Text+"', '"+password.Text+"','Active'); ", conn);


                    SqlDataReader myreader;
                   

                    myreader = cmd.ExecuteReader();
                    MessageBox.Show("Sucessfully Registered..");
                    Login l2 = new Login(id.Text , password.Text);
                    l2.Show();
                    conn.Close();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                gender = "Male";            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                gender = "Female";
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dept = comboBox1.SelectedItem.ToString();
        }
    }
}

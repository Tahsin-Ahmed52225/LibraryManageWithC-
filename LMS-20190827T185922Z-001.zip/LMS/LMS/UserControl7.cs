﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LMS
{
    public partial class bookr : UserControl
    {
        string user1;
        public void set(string a)
        {
            user1 = a;
        }
        public void listv (string user1)
        {
            string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select book_id,book_name,issu_date from book where stu_id = '" + user1 + "'", conn);
            SqlDataReader myreader;
            myreader = cmd.ExecuteReader();
            if (myreader.HasRows)
            {
                while (myreader.Read())
                {


                    ListViewItem lv = new ListViewItem(myreader[0].ToString());
                    lv.SubItems.Add(myreader[1].ToString());
                    lv.SubItems.Add(myreader[2].ToString());

                    string date = myreader["issu_date"].ToString();
                    DateTime oDate = Convert.ToDateTime(date);
                    DateTime Rdate = oDate.AddDays(7);
                    string format = "yyyy MM dd";
                    string RD = Rdate.ToString(format);
                    lv.SubItems.Add(RD);

                    listView1.Items.Add(lv);
                }
            }
            conn.Close();
        }
       
        public void label(string user1)
        {
            try
            {
                string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                SqlCommand cmd = new SqlCommand("select stu_name,stu_gender,stu_dept,stu_dob,stu_num,stu_mail,stu_add,stu_state from student where stu_id ='" + user1 + "'", conn);
                SqlDataReader myreader;
                myreader = cmd.ExecuteReader();

                while (myreader.Read())
                {

                    label1.Text = myreader["stu_name"].ToString();
                    label2.Text = myreader["stu_gender"].ToString();
                    label3.Text = myreader["stu_dept"].ToString();
                    label4.Text = myreader["stu_dob"].ToString();
                    label5.Text = myreader["stu_num"].ToString();
                    label6.Text = myreader["stu_mail"].ToString();
                    label7.Text = myreader["stu_add"].ToString();
                    label17.Text = myreader["stu_state"].ToString();


                }
                conn.Close();
               
                DateTime oDate = DateTime.Now;
                
                string format = "yyyy MM dd";
                string RD = oDate.ToString(format);
                label8.Text = RD;

                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        public bookr()
        {
            InitializeComponent();
            
        }

        private void bookr_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            listv(user1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                SqlCommand cmd = new SqlCommand("update  book set issu_date ='-',stu_id='-' where stu_id = '" + user1 + "' and book_id ='" + textBox1.Text + "'", conn);
                SqlDataReader myreader;
                myreader = cmd.ExecuteReader();
                MessageBox.Show("Book Returned");
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                SqlCommand cmd = new SqlCommand("update  student set stu_state ='Locked' where stu_id = '" + user1 + "'", conn);
                SqlDataReader myreader;
                myreader = cmd.ExecuteReader();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                SqlCommand cmd = new SqlCommand("update  student set stu_state ='Active' where stu_id = '" + user1 + "'", conn);
                SqlDataReader myreader;
                myreader = cmd.ExecuteReader();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
    }


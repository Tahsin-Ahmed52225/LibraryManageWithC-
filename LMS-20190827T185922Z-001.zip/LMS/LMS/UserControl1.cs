﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LMS
{
    public partial class newbook : UserControl
    {
        public newbook()
        {
            InitializeComponent();
        }
        string dept;
        string edition;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (name.Text == "" || aurthor.Text == "" || id.Text == "")
                {
                    MessageBox.Show("Missing infromation !!!");
                }

                else
                {
                    string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";

                    SqlConnection conn = new SqlConnection(cs);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("insert into book(book_id,book_name,aurthor, book_dept ,book_edition, issu_date , stu_id,status_) values('" + id.Text + "', '" + name.Text + "', '" + aurthor.Text + "', '" + dept + "', '" + edition + "', '-' , '-','-'); ", conn);


                    SqlDataReader myreader;


                    myreader = cmd.ExecuteReader();
                    MessageBox.Show("Sucessfully Registered..");
                    conn.Close();

                    id.Clear();
                    name.Clear();
                    aurthor.Clear();
                    dept = null;
                    edition = null;
                
                    

                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dept = comboBox1.SelectedItem.ToString();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            edition = numericUpDown1.Value.ToString();
        }
    }
}

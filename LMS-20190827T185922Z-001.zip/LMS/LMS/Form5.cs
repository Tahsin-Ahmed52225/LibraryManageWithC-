﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LMS
{
    public partial class Forgetpass : Form
    {
        public Forgetpass()
        {
            InitializeComponent();
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void Reset_Click(object sender, EventArgs e)
        {
            
                try
                {
                if (radioButton1.Checked)
                  {
                    string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";

                    SqlConnection conn = new SqlConnection(cs);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from student where stu_id ='" + id.Text + "' and stu_mail ='" + mail.Text + "' and  stu_ra ='"+ra.Text+"'", conn);


                    SqlDataReader myreader;


                    myreader = cmd.ExecuteReader();
                    int count = 0;
                    while (myreader.Read())
                    {
                        count = count + 1;
                    }

                    if (count == 1)
                    {
                        newStu l1 = new newStu(id.Text);
                        l1.Show();
                       
                    }

                    else if (count != 1)
                    {
                        MessageBox.Show("Incorrect info try again");
                    }
                    conn.Close();
                }
             else   if (radioButton2.Checked)
                {
                    string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";

                    SqlConnection conn = new SqlConnection(cs);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from librarian where li_id ='" + id.Text + "' and li_mail ='" + mail.Text + "' and  li_ra ='" + ra.Text + "'", conn);


                    SqlDataReader myreader;


                    myreader = cmd.ExecuteReader();
                    int count = 0;
                    while (myreader.Read())
                    {
                        count = count + 1;
                    }

                    if (count == 1)
                    {
                        newli l1 = new newli(id.Text);
                        l1.Show();

                    }

                    else if (count != 1)
                    {
                        MessageBox.Show("Incorrect info try again");
                    }
                    conn.Close();
                }
            }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            
        }

        private void ra_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

create table student(
  stu_id varchar(30) primary key not null,
  stu_name varchar(30) not null,
  stu_gender varchar(10) not null,
  stu_dept varchar(20) not null,
  stu_dob varchar(20) not null,
  stu_num varchar(20) not null,
  stu_mail varchar(30) not null,
  stu_add varchar (30) not null,
  stu_ra varchar(30) not null,
  stu_pass varchar(30) not null,
  stu_state varchar (30) not null,
);
select stu_name,stu_gender,stu_dept,stu_num from student where stu_id ='CSE06407536'
select * from student;


insert into student(stu_id , stu_name ,stu_gender , stu_dept ,  stu_dob ,  stu_num ,  stu_mail ,  stu_add ,  stu_ra, stu_pass)
values ('cse06467541','Tahsin','Male','CSE','1998-04-20','01936152225','tahsin@gmail.com','Dhaka','Riyadh','1111');
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LMS
{
    public partial class Login : Form
    {
        public Login(string a , string b)
        {
            InitializeComponent();
            password.PasswordChar = '*';
            username.Text = a;
            password.Text = b;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            
            if (radioButton2.Checked)
            {
                try
                {
                    string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";

                    SqlConnection conn = new SqlConnection(cs);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from librarian where li_id ='" + username.Text + "' and li_pass='" + password.Text + "'", conn);


                    SqlDataReader myreader;


                    myreader = cmd.ExecuteReader();

                    int count = 0;
                    while (myreader.Read())
                    {
                        count = count + 1;
                    }

                    if (count == 1)
                    {
                        Librarian l1 = new Librarian();
                        l1.Show();
                        
                        username.Clear();
                        password.Clear();

                    }

                    else if (count != 1)
                    {
                        MessageBox.Show("Username and Password is not correct");
                    }



                    conn.Close();
                   
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
            else if (radioButton1.Checked)
            {
                try
                {
                    string cs = "Data Source=DESKTOP-NGA40KK\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";

                    SqlConnection conn = new SqlConnection(cs);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from student where stu_id ='" + username.Text + "' and stu_pass='" + password.Text + "'", conn);


                    SqlDataReader myreader;


                    myreader = cmd.ExecuteReader();

                   while (myreader.Read())
                    {
                        if (myreader.HasRows)
                        {
                            if (myreader["stu_state"].ToString() == "Active")
                            {
                                Student s1 = new Student(username.Text);
                                s1.Show();
                                username.Clear();
                                password.Clear();
                            }
                            else
                            {
                                MessageBox.Show("Account Locked");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Username or Password incorrect");
                        }
                    }

                    conn.Close();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else { MessageBox.Show("Choose Student/Librarian log in");
            }
            
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SignUp s1 =new  SignUp();
            s1.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Forgetpass f1 = new Forgetpass();
            f1.Show();
        }

        private void password_TextChanged(object sender, EventArgs e)
        {

        }
    }


    }
    


